# Fred — Phase 0 Architecture Note

## Status
Approved

## Context
Phase 0 establishes the dependency and infrastructure baseline that every subsequent phase builds on: Supabase auth plumbing, ShadCN component scaffolding, the NPS API transport fix, and stub SEO routes. Nothing functional ships in Phase 0, but every later phase assumes these foundations are in place and correctly structured.

---

## Decisions

### 1. Supabase client structure — `src/lib/supabase/`

Three files, three responsibilities:

- **`src/lib/supabase/client.ts`** — browser singleton, created once with `createBrowserClient` from `@supabase/ssr`. Must be a module-level singleton (call `createBrowserClient` at the top level, not inside a function) so React doesn't re-instantiate it on every render.

- **`src/lib/supabase/server.ts`** — per-request server client, created fresh on every call using `createServerClient` from `@supabase/ssr`. Reads and writes cookies via the `cookies()` API from `next/headers`. Must `await cookies()` (Next.js 16 cookies API is async). Do not cache or share this instance across requests.

- **`src/lib/supabase/middleware.ts`** — helper that the root proxy calls. Creates a server client (same cookie adapter pattern) and calls `supabase.auth.getUser()` to refresh the session token before returning the modified response. This is the correct call per Supabase SSR docs — `getSession()` does not validate the JWT against the server and must not be used here.

Rationale: `@supabase/ssr` replaces the deprecated `auth-helpers-nextjs` package. The cookie adapter pattern is the only supported approach for App Router + server components.

### 2. Next.js 16 file convention change — `proxy.ts` replaces `middleware.ts`

**Breaking change from training data.** In Next.js 16, `middleware.ts` is deprecated and renamed to `proxy.ts`. The exported function name changes from `middleware` to `proxy`. The file lives at the project root (or inside `src/` if using the src directory layout — this project uses `src/`, so the path is `src/proxy.ts`).

The spec's `Files to Create` section lists `middleware.ts` — this must be created as `proxy.ts` instead. The `src/lib/supabase/middleware.ts` helper file (internal module, not the Next.js file convention) can keep the name `middleware.ts` since it is just a regular module, not the Next.js file convention.

The proxy function must:
1. Call the Supabase session refresh helper from `src/lib/supabase/middleware.ts`
2. Forward the modified response (with refreshed session cookies)
3. Use the standard matcher that excludes `_next/static`, `_next/image`, and static assets

The `config` export and matcher syntax are unchanged from prior versions.

### 3. `rejectUnauthorized: false` removal strategy

The current `/api/parks/route.ts` uses `node:https` directly to bypass SSL inspection proxies (corporate MITM). Next.js 16 runs under Node 22+ and uses Undici as its native fetch implementation.

**Decision: Velma attempts removal in Phase 0.** Replace `npsGet` with a plain `fetch(url, { next: { revalidate: 3600 } })` call. If the NPS API responds successfully, delete the `node:https` block entirely. If SSL errors occur in the dev environment, comment out the fetch attempt, restore the `node:https` block (also commented), and add a clear note explaining the corporate proxy situation so the workaround is not mistaken for production intent.

Do not `NODE_TLS_REJECT_UNAUTHORIZED=0` as an environment variable — that disables SSL verification process-wide and must never be committed.

The NPS route also needs `next: { revalidate: 3600 }` added to the fetch options (currently absent) when switching to native fetch.

### 4. ShadCN init — Tailwind v4 compatibility

ShadCN has first-class Tailwind v4 support. The correct init command for this project is:

```
npx shadcn@latest init
```

The CLI will detect Tailwind v4 automatically from `@tailwindcss/postcss` in `devDependencies` and configure itself accordingly. Do not pass `--legacy-peer-deps` or force v3 mode.

Key v4 differences ShadCN handles automatically:
- No `tailwind.config.js` — configuration lives in `globals.css` via `@theme` directives
- CSS variable tokens are injected into the existing `@import 'tailwindcss'` block in `src/app/globals.css`
- `components.json` is generated in the project root — this is correct, leave it there
- ShadCN components are written to `src/components/ui/` by default; accept this path

Daphne must not run `npx shadcn init --tailwind-version 3` or any flag that downgrades Tailwind compatibility.

### 5. Module boundary for Supabase imports

`src/lib/supabase/` is the single ownership boundary for all Supabase client instantiation.

Permitted Supabase imports outside `src/lib/supabase/`:
- `src/context/AuthContext.tsx` — may import from `src/lib/supabase/client.ts` only
- Server Components and Route Handlers — may import from `src/lib/supabase/server.ts` only
- `src/proxy.ts` — imports from `src/lib/supabase/middleware.ts` only

Forbidden: importing `@supabase/supabase-js` or `@supabase/ssr` directly anywhere outside `src/lib/supabase/`. All Supabase types (`User`, `Session`, etc.) are re-exported from `src/lib/supabase/` so consumers never need to import from the Supabase packages directly.

Rationale: contains the blast radius if we need to swap client configuration, add error handling, or change the cookie adapter.

### 6. `robots.ts` and `sitemap.ts` — Phase 0 stubs only

Both files are created as stubs in Phase 0. No dynamic park routes are fetched at this stage.

- `src/app/robots.ts` — returns a static `MetadataRoute.Robots` object: allow all crawlers, disallow `/api/`, point sitemap to `https://parkreach.app/sitemap.xml`
- `src/app/sitemap.ts` — returns a static `MetadataRoute.Sitemap` array with only the top-level routes: `/`, `/auth/login`, `/profile`. Add `export const revalidate = 86400` but do not fetch park routes yet.

Dynamic park routes (`/parks/[parkCode]`) are deferred to Phase 7. Add a `// TODO(phase-7): add dynamic park routes from NPS API` comment.

### 7. `package.json` name field

The `package.json` `name` field is currently `"accessible-parks"`. The spec notes it "already done" but it has not been changed. Velma must rename it to `"parkreach"` as part of Phase 0.

### 8. `.env.schema` additions

Velma must append the following to `.env.schema` using `pass()` references consistent with the existing `NPS_API_KEY` entry:

```
# @sensitive @required @type=string
# Supabase project URL — fetched from pass store at "supabase/url"
NEXT_PUBLIC_SUPABASE_URL=pass("supabase/url")

# @sensitive @required @type=string
# Supabase anonymous/public key — fetched from pass store at "supabase/anon-key"
NEXT_PUBLIC_SUPABASE_ANON_KEY=pass("supabase/anon-key")

# @sensitive @required @type=string
# Supabase service role key (server-only) — fetched from pass store at "supabase/service-role-key"
SUPABASE_SERVICE_ROLE_KEY=pass("supabase/service-role-key")

# @sensitive @required @type=string
# Google Maps JavaScript API key — fetched from pass store at "google/maps-api-key"
GOOGLE_MAPS_API_KEY=pass("google/maps-api-key")
```

`SUPABASE_SERVICE_ROLE_KEY` must never appear in client-side code or be prefixed `NEXT_PUBLIC_`. It is used only in server-side Supabase admin operations (Phase 1 migrations).

---

## Constraints for Daphne and Velma

- Do not create `middleware.ts` at the project root or in `src/`. The Next.js 16 file convention is `proxy.ts`. The helper module at `src/lib/supabase/middleware.ts` is fine — it is not the file convention, it is a regular module.
- Do not import `@supabase/supabase-js` or `@supabase/ssr` outside of `src/lib/supabase/`. No exceptions.
- Do not call `supabase.auth.getSession()` in `src/proxy.ts` — use `supabase.auth.getUser()`. The session getter does not revalidate the JWT.
- Do not add `'use client'` to any file in `src/lib/supabase/`. The browser client is a singleton module but it is not a React component or hook.
- Do not commit `NODE_TLS_REJECT_UNAUTHORIZED=0` in any environment file or script.
- `SUPABASE_SERVICE_ROLE_KEY` must not have the `NEXT_PUBLIC_` prefix and must not be referenced in any client component or browser-side code.
- `components.json` belongs in the project root — do not move it into `src/`.
- Phase 0 does not touch `src/app/page.tsx` beyond what the spec describes for this phase. The existing POC structure in `page.tsx` is not refactored here — that is Phase 4's job.
- `robots.ts` and `sitemap.ts` are stubs. Do not fetch from the NPS API in either file during Phase 0.

---

## Open Questions

1. **Pass store paths for Supabase keys** — The `.env.schema` entries above assume pass store paths `supabase/url`, `supabase/anon-key`, and `supabase/service-role-key`. Confirm these paths with the project owner before running `varlock` in dev.

2. **Google Maps API key scope** — `GOOGLE_MAPS_API_KEY` covers both the Maps JS API and the Distance Matrix API per the spec. Confirm with the project owner whether these share one key or use separate restricted keys (the Distance Matrix is a server-side-only call, so a separate server key with HTTP referrer restrictions removed would be more secure).

3. **SSL inspection environment** — The `rejectUnauthorized: false` workaround suggests this project is developed behind a corporate SSL proxy. Velma should test the plain `fetch` path first in the actual dev environment before declaring the workaround can be removed. If removed, note it in the commit message so it can be re-added if a team member hits the issue on a different network.
