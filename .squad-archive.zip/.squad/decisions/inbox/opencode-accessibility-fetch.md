# Design Note: NPS Amenities API for Accessibility Data

## Problem
The `accessibility` field is not available on the `/parks` endpoint. Need to fetch from `/amenities/parksplaces` endpoint to get accessibility information.

## Options

### Option A: New API Route + Server Component (Recommended)
Create `/api/amenities/[parkCode]` route that fetches from NPS amenities/parksplaces endpoint. Call from park detail page server component.

- **Pros:** Server-side, cached, consistent with existing pattern
- **Cons:** Another API route to maintain

### Option B: Client-side Fetch
Add client-side fetch in AccessibilityInfo component.

- **Pros:** Simpler
- **Cons:** Additional request on page load, no server-side caching

## Decision
Go with Option A — matches existing pattern (server-side fetch with caching).

## Implementation Plan
1. Create `/api/amenities/[parkCode]` route that fetches from NPS amenities/parksplaces endpoint
2. Create `useAmenities` hook to fetch data
3. Update AccessibilityInfo component to use hook
4. Add type definitions for amenities response