# Phase 6 — Park of the Day + URL-Driven State

## Architecture Decision

**Decision**: Split `page.tsx` into a Server Component shell with a client island.

`page.tsx` becomes an RSC that:
1. Renders the header (inline, importing client components like `AuthButton` and `DarkModeToggle`)
2. Renders `ParkOfTheDay` directly (RSC hero, server-rendered, cached 24h)
3. Renders a new `<ExplorerClient>` client component that owns all interactive state

**Rationale**:
- `ParkOfTheDay` is already an RSC with `revalidate: 86400` — it must be rendered from an RSC to preserve server-side caching
- The park grid requires `useParks` (client-side fetching with pagination), so it stays client-side
- Next.js 16 App Router convention: RSC shell → client islands for interactivity
- This avoids the impossibility of importing an RSC into a `"use client"` component

**Trade-offs**:
- Slightly more files (new `ExplorerClient` component)
- Props pass-through from `ExplorerClient` to `SearchFilter` and `ViewToggle`
- But cleaner separation: server rendering for hero, client rendering for interactive explorer

---

## URL State Strategy

**Decision**: Use `nuqs` library for URL-driven state.

**URL params**:

| Param | Purpose | Default |
|-------|---------|---------|
| `?q=` | Search query | `""` |
| `?state=` | State code (e.g., `CA`) | `""` |
| `?desig=` | Designation (e.g., `National Parks`) | `"All"` |
| `?acc=` | Accessibility filter | `""` |
| `?view=` | View mode | `"cards"` |

**Why `nuqs` over alternatives**:

- **vs. manual `useSearchParams` + `useRouter`**: `nuqs` eliminates boilerplate for debouncing, shallow updates, and initializing from URL. Manual approach would require ~40 lines of effect/state wiring per param.
- **vs. server-side filtering via `searchParams` prop**: Not compatible — `useParks` does client-side fetching with pagination, so filters must be applied client-side.
- **`nuqs` benefits**: Built-in debouncing (`debounceMs`), TypeScript-first, shallow routing (no scroll jump), SSR-compatible, and actively maintained for Next.js App Router.

**Usage pattern in `ExplorerClient`**:
```typescript
const [search, setSearch] = useQueryState('q', { defaultValue: '', debounceMs: 300 })
const [stateCode, setStateCode] = useQueryState('state', { defaultValue: '' })
const [designation, setDesignation] = useQueryState('desig', { defaultValue: 'All' })
const [accessibility, setAccessibility] = useQueryState('acc', { defaultValue: '' })
const [view, setView] = useQueryState('view', { defaultValue: 'cards' })
```

These values flow into `useParks(search, stateCode, designation)` and `SearchFilter` / `ViewToggle` as controlled props.

---

## Component Structure

### New `page.tsx` (RSC)
```
page.tsx (Server Component)
├── <header> (inline)
│   ├── Logo + title
│   ├── <AuthButton />
│   └── <DarkModeToggle />
├── <ParkOfTheDay /> (RSC — hero section)
└── <ExplorerClient /> (client component — everything below hero)
```

### New `ExplorerClient.tsx` (client component)
```
ExplorerClient
├── <SearchFilter /> (controlled via nuqs props)
├── <ViewToggle /> (controlled via nuqs props)
├── Results count (aria-live region)
├── Error state
├── Loading skeleton (initial load)
├── Conditional view rendering:
│   ├── view === 'cards' → <ParkCard /> grid
│   ├── view === 'minimal' → <ParkCardMinimal /> list
│   └── view === 'map' → <ParkMap /> (lazy-loaded)
├── Load more button (pagination)
├── <ParkModal />
├── <AuthModal />
└── <footer>
```

### Files changed
- `src/app/page.tsx` — rewritten as RSC shell
- `src/components/ExplorerClient.tsx` — new client component (extract from current `page.tsx`)
- `src/components/ViewToggle.tsx` — update `ViewMode` type to include `'cards' | 'minimal' | 'map'`
- `src/components/SearchFilter.tsx` — no structural change; continues to receive controlled props

### Files needed (Phase 4 work, flagged as dependency)
- `src/components/ParkCardMinimal.tsx` — minimal view (Phase 4)
- `src/components/ParkMap.tsx` — map view, lazy-loaded (Phase 4)

---

## Implementation Order

### Step 1 — Install `nuqs` (prerequisite)
- **Owner**: Velma
- **Task**: `npm install nuqs`
- **No dependencies**

### Step 2 — Create `ExplorerClient` and refactor `page.tsx`
- **Owner**: Daphne
- **Task**: Extract all interactive state/logic from `page.tsx` into new `src/components/ExplorerClient.tsx` client component. Rewrite `page.tsx` as RSC that renders header + `<ParkOfTheDay />` + `<ExplorerClient />`.
- **Depends on**: Step 1 (nuqs available)

### Step 3 — Wire URL state with `nuqs`
- **Owner**: Daphne
- **Task**: In `ExplorerClient`, replace `useState` for `search`, `stateCode`, `designation`, `accessibility` with `nuqs` `useQueryState` hooks. Wire `debouncedSearch` logic into the `nuqs` setter with `debounceMs: 300`.
- **Depends on**: Step 2

### Step 4 — Update `ViewToggle` and wire `?view=`
- **Owner**: Daphne
- **Task**: Update `ViewToggle.tsx`:
  - Change `ViewMode` type from `'list' | 'map'` to `'cards' | 'minimal' | 'map'`
  - Rename "List" button to "Cards" (matches SPEC terminology)
  - Add "Minimal" button
  - Wire to `nuqs` `useQueryState('view')` in `ExplorerClient`
- **Depends on**: Step 3

### Step 5 — Wire `ParkOfTheDay` into `page.tsx`
- **Owner**: Daphne
- **Task**: Already done as part of Step 2 (rendering `<ParkOfTheDay />` in the RSC shell). Verify it renders as hero between header and explorer.
- **Depends on**: Step 2

### Parallel opportunities
- **Velma** can install `nuqs` (Step 1) while **Daphne** reviews the current `page.tsx` structure
- **Shaggy** can stand by to verify builds pass after each step

---

## Work Assignment

| Step | Task | Owner | Est. |
|------|------|-------|------|
| 1 | Install `nuqs` | Velma | 5 min |
| 2 | Create `ExplorerClient`, refactor `page.tsx` to RSC | Daphne | 45 min |
| 3 | Wire filters to URL params via `nuqs` | Daphne | 30 min |
| 4 | Update `ViewToggle` (3 modes), wire `?view=` | Daphne | 30 min |
| 5 | Verify `ParkOfTheDay` renders as hero | Daphne | 10 min |
| — | Build verification + lint | Shaggy | 15 min |

**Total frontend time**: ~2 hours (Daphne)
**Total backend time**: ~5 min (Velma — dependency install)

---

## Risks / Open Questions

1. **`ParkCardMinimal` and `ParkMap` don't exist yet** — These are Phase 4 deliverables. For Phase 6, the `view` param and `ViewToggle` can be wired, but the minimal/map views will render fallback UI until Phase 4 is done. Flag with TODO comments.

2. **Pagination reset on filter change** — When a filter changes (e.g., search query), `useParks` should reset to page 1. Verify the current `useParks` hook handles this correctly when its input args change.

3. **`nuqs` compatibility with Next.js 16** — The AGENTS.md warns that Next.js 16 has breaking changes. Test `nuqs` with a simple `useQueryState` in a throwaway component before full implementation. If incompatible, fall back to manual `useSearchParams` + `useRouter`.

4. **`ParkOfTheDay` error state** — The current `ParkOfTheDay` returns `null` on fetch failure, which silently hides the hero. Consider adding a fallback minimal hero or a TODO for error handling.

5. **Accessibility filter is client-side only** — `SearchFilter` applies the accessibility filter client-side on the already-fetched park list (NPS API limitation per SPEC). This doesn't change with URL params — the `?acc=` param will still be filtered client-side in `ExplorerClient`.

6. **SEO for filtered views** — Filtered/card-grid pages are client-rendered with URL params. Search engines may not execute JS to see the filtered results. This is acceptable for explorer pages (not the primary SEO target). Park detail pages (`/parks/[parkCode]`) remain fully server-rendered for SEO.
