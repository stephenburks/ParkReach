# Accessibility Audit — Phase 2

**Date**: 2026-05-03
**Author**: Shaggy (Test/A11y)
**Status**: Resolved

---

## Method

Code review of all interactive components + axe-core automated scan (jsdom, color-contrast disabled — no computed styles in test environment). Manual keyboard pattern review.

---

## Violations Found & Fixed

### Critical — WCAG 4.1.2 (Name, Role, Value)

| Component | Element | Issue | Fix Applied |
|-----------|---------|-------|-------------|
| `SearchFilter` | `<input type="search">` | No `<label>` — placeholder is not a label substitute | Added `<label htmlFor="park-search" className="sr-only">` |
| `SearchFilter` | State `<select>` | No `<label>` | Added `<label htmlFor="park-state" className="sr-only">` |
| `SearchFilter` | Accessibility `<select>` | No `<label>` | Added `<label htmlFor="park-accessibility" className="sr-only">` |
| `AuthModal` | `<input type="email">` | No `<label>` — placeholder is not a label substitute | Added `<label htmlFor="auth-email" className="sr-only">` |

### Moderate — WCAG 4.1.2 (State not communicated)

| Component | Issue | Fix Applied |
|-----------|-------|-------------|
| `SearchFilter` designation buttons | Active button had no `aria-pressed` — state not communicated to AT | Added `aria-pressed={designation === d}` |
| `SearchFilter` designation group | No group label — AT couldn't identify what the buttons filtered | Added `role="group" aria-label="Filter by designation"` |

### Moderate — Keyboard UX (WCAG 2.1.1)

| Component | Issue | Fix Applied |
|-----------|-------|-------------|
| `ParkCard` save buttons overlay | Buttons are in tab order but invisible (opacity-0 hover-only) — confusing for keyboard users | Added `group-focus-within:opacity-100` so overlay appears when focus enters |

---

## No Issues Found

- `ViewToggle` — correct `aria-pressed` on all three buttons ✓
- `ParkCardMinimal` — correct `aria-label`, `role="button"`, `tabIndex` ✓
- `AuthModal` — `role="dialog"`, `aria-modal`, `aria-labelledby`, focus trap, Escape close ✓
- `SkipLink` — present in layout ✓
- Park grids — `role="list"` on `<ul>` ✓
- Results count — `aria-live="polite"` ✓
- `DarkModeToggle` — `aria-label` on icon button ✓

---

## Out of Scope (jsdom limitations)

- Color contrast ratios — requires real browser or external tool (Lighthouse, browser DevTools)
- Focus order visual validation — requires manual browser walkthrough
- Screen reader announcement quality — requires NVDA/VoiceOver testing

## Recommendation

Run a Lighthouse a11y audit on the deployed app before launch. Focus on color contrast (stone-400 on white backgrounds may be borderline WCAG AA at smaller text sizes).
