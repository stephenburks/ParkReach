# Design Plan: Phase 4 Gaps — ParkCardMinimal & ParkMap

**Date**: 2026-05-02
**Author**: Fred (Lead Architect)
**Status**: Draft
**Related**: Phase 4 (Explorer Views), `docs/SPEC.md`

---

## Context

Phase 4 has two remaining gaps blocking completion:
1. `ParkCardMinimal` — deleted during cleanup, needs recreation
2. `ParkMap` — deleted (used wrong library Leaflet), needs recreation with Google Maps per spec

Current state: `ExplorerClient.tsx` renders placeholder "coming soon" text for both views.

---

## 1. ParkCardMinimal Design

### What it shows (single-row, dense layout, no image)

Each row displays, left-to-right:

| Element | Source | Notes |
|---------|--------|-------|
| Park name | `park.fullName` | Bold, truncated with ellipsis at ~60ch |
| Designation badge | `park.designation` | Small pill, same style as `ParkCard.tsx:54` |
| States | `park.states` | Split on `,` → join with `·` delimiter |
| Description snippet | `park.description` | `line-clamp-1`, max ~100ch, muted text |
| Wishlist + Visited | `WishlistButton`, `VisitedButton` | Using `minimal` prop (already supported) |

### Layout

```
<!-- Single row per park, dense -->
<li class="flex items-center gap-4 px-4 py-2.5 border-b border-stone-100 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-800/50 transition-colors cursor-pointer">
  <div class="flex-1 min-w-0"> <!-- truncate wrapper -->
    <div class="flex items-center gap-2">
      <span class="font-semibold text-sm text-park-bark dark:text-park-cream truncate">
        {park.fullName}
      </span>
      {park.designation && (
        <span class="shrink-0 text-[10px] font-medium bg-park-forest/10 text-park-forest px-2 py-0.5 rounded-full">
          {park.designation}
        </span>
      )}
    </div>
    <div class="flex items-center gap-3 mt-0.5">
      <span class="text-xs text-park-stone dark:text-stone-400 truncate">
        📍 {states}
      </span>
      <span class="text-xs text-stone-500 dark:text-stone-400 truncate">
        {park.description}
      </span>
    </div>
  </div>
  <div class="flex items-center gap-1 shrink-0">
    <WishlistButton parkCode={park.parkCode} minimal />
    <VisitedButton parkCode={park.parkCode} minimal />
  </div>
</li>
```

### Accessibility

- `role="button"` on the clickable row (`<div>` or `<li>` with inner interactive `<div>`)
- `tabIndex={0}` + keyboard handler (`Enter`/`Space` → `onSelect(park)`)
- `aria-label` on each row: `"View details for {park.fullName}"`
- Buttons have `aria-label` via `WishlistButton`/`VisitedButton` (already implemented)
- The list container uses `<ul role="list">` consistent with card view pattern
- Focus ring: `focus-visible:ring-2 focus-visible:ring-park-forest focus-visible:ring-offset-2 focus-visible:outline-none`

### Interaction

- Click or keyboard activation → `onSelect(park)` → sets `?park={parkCode}` (opens `ParkModal`)
- Same pattern as `ParkCard.tsx:60-66`

### File

`src/components/ParkCardMinimal.tsx` — `'use client'` (needs event handlers)

---

## 2. ParkMap Design

### Library

Per `package.json` + SPEC: install `@vis.gl/react-google-maps`. Remove old `@types/google.maps` if present.

```bash
npm install @vis.gl/react-google-maps
```

### Lazy Loading

Per SPEC: `dynamic(() => import('./ParkMap'), { ssr: false })` in `ExplorerClient.tsx`.

The map JS bundle (Google Maps + react-google-maps) only loads when user switches to map view.

### Component Structure

```
ParkMap.tsx          — main map, accepts parks array + onParkSelect
ParkMapPin.tsx       — custom marker with InfoWindow
```

### ParkMap.tsx

```tsx
'use client'

import { APIProvider, Map, AdvancedMarker, InfoWindow } from '@vis.gl/react-google-maps'
import { useState } from 'react'
import type { Park } from '@/types/park'
import { ParkMapPin } from './ParkMapPin'

interface Props {
  parks: Park[]
  onParkSelect: (park: Park) => void
}

// Default center: geographic center of US (39.8283, -98.5795)
const DEFAULT_CENTER = { lat: 39.8283, lng: -98.5795 }
const DEFAULT_ZOOM = 4

export function ParkMap({ parks, onParkSelect }: Props) {
  const [selectedPark, setSelectedPark] = useState<Park | null>(null)

  const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY

  if (!apiKey) {
    return <div className="h-[600px] flex items-center justify-center bg-stone-100 dark:bg-stone-800 rounded-xl">
      <p className="text-park-stone">Map unavailable — API key not configured</p>
    </div>
  }

  // Filter parks with valid coordinates
  const parksWithCoords = parks.filter(p => p.latitude && p.longitude)

  return (
    <APIProvider apiKey={apiKey}>
      <div className="h-[600px] rounded-xl overflow-hidden border border-stone-200 dark:border-stone-700">
        <Map
          defaultCenter={DEFAULT_CENTER}
          defaultZoom={DEFAULT_ZOOM}
          mapId={process.env.NEXT_PUBLIC_GOOGLE_MAP_ID}
          gestureHandling="greedy"
          disableDefaultUI={false}
        >
          {parksWithCoords.map(park => (
            <AdvancedMarker
              key={park.parkCode}
              position={{
                lat: parseFloat(park.latitude),
                lng: parseFloat(park.longitude),
              }}
              title={park.fullName}
              onClick={() => setSelectedPark(park)}
            />
          ))}

          {selectedPark && (
            <InfoWindow
              position={{
                lat: parseFloat(selectedPark.latitude),
                lng: parseFloat(selectedPark.longitude),
              }}
              onCloseClick={() => setSelectedPark(null)}
            >
              <div className="p-1 max-w-[250px]">
                <h3 className="font-semibold text-sm text-park-bark dark:text-park-cream mb-1">
                  {selectedPark.fullName}
                </h3>
                <p className="text-xs text-stone-500 mb-2">
                  {selectedPark.states.split(',').join(' · ')}
                </p>
                <button
                  onClick={() => onParkSelect(selectedPark)}
                  className="text-xs text-park-forest font-medium hover:underline"
                >
                  View details →
                </button>
              </div>
            </InfoWindow>
          )}
        </Map>
      </div>
    </APIProvider>
  )
}
```

### Clustering

`@vis.gl/react-google-maps` doesn't include clustering out of the box. Google Maps marker clustering requires `@googlemaps/markerclusterer` + `@googlemaps/markerclustererplus` (legacy) or the new `@googlemaps/markerclusterer` with a custom wrapper.

**Decision**: Skip clustering for initial implementation. NPS currently returns ~470 parks total — at zoom level 4 (default), individual markers are manageable. Add clustering in a follow-up if user testing shows it's needed at deeper zooms.

If clustering is needed later:
```bash
npm install @googlemaps/markerclusterer
```
Wrap markers in a `<MarkerClusterer>` component.

### ParkMapPin.tsx

For now, use `AdvancedMarker` directly (default Google Maps pin). Custom pin component can be added later if design calls for branded pins.

### Accessibility

- "Skip map, view as list" link above the map (SPEC requirement, `aria-label`, `href="#main-content"`)
- Map container has `role="application"` and `aria-label="Map of national parks"`
- InfoWindow is keyboard-accessible (Google handles this)
- Focus management: skip link moves focus to the card/minimal list

### Props

Parks passed from `ExplorerClient.tsx` — only currently loaded parks (not all ~470). This is consistent with the SPEC note about filtering only loaded parks.

### Environment Variables

Add to `.env.schema`:
```
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY="pass(GOOGLE_MAPS_API_KEY)"
NEXT_PUBLIC_GOOGLE_MAP_ID="pass(GOOGLE_MAP_ID)"
```

`GOOGLE_MAP_ID` is created in Google Cloud Console → Maps → Map Management.

---

## 3. Implementation Approach

### Option A: Daphne does both (serial)

Daphne implements `ParkCardMinimal` first (easier, ~1 hour), then `ParkMap` (~2-3 hours).

**Pros**: Single context, no handoff overhead
**Cons**: Phase 4 blocks on one person

### Option B: Split by complexity (parallel)

Daphne does `ParkCardMinimal` (straightforward, follows `ParkCard.tsx` patterns).
Daphne does `ParkMap` (requires new library, learning curve).

**Verdict**: Option A. The two components are both in `ExplorerClient.tsx` and share the same parent context. Having one person do both avoids context-switching overhead. `ParkCardMinimal` is simple enough that the serial approach adds minimal delay.

---

## 4. Implementation Order & Work Assignment

### Step 1: Install dependency (5 min)

**Who**: Daphne
**What**: `npm install @vis.gl/react-google-maps`
**Verify**: `package.json` updated, lockfile regenerated

---

### Step 2: Create `ParkCardMinimal.tsx` (45 min)

**Who**: Daphne
**File**: `src/components/ParkCardMinimal.tsx`
**Pattern**: Mirror `ParkCard.tsx` — `memo`, keyboard handler, `WishlistButton`/`VisitedButton` with `minimal` prop
**Key differences from `ParkCard`**:
- No `<article>` wrapper (it's a `<li>` inside a `<ul>`)
- No image
- Single row (`flex items-center`)
- `line-clamp-1` on description
- Smaller text sizes (`text-sm` / `text-xs`)

**Wire into `ExplorerClient.tsx`**:
```tsx
// Replace the placeholder at line 150-156
{view === 'minimal' && (
  <ul className="divide-y divide-stone-100 dark:divide-stone-700" role="list">
    {accessibilityFilteredParks.map((park) => (
      <li key={park.id}>
        <ParkCardMinimal park={park} onSelect={handleSelectPark} />
      </li>
    ))}
  </ul>
)}
```

---

### Step 3: Lazy-load `ParkMap` in `ExplorerClient.tsx` (15 min)

**Who**: Daphne
**What**: Add `dynamic` import at top of `ExplorerClient.tsx`

```tsx
import dynamic from 'next/dynamic'

const ParkMap = dynamic(
  () => import('@/components/ParkMap'),
  {
    ssr: false,
    loading: () => (
      <div className="h-[600px] flex items-center justify-center bg-stone-100 dark:bg-stone-800 rounded-xl">
        <p className="text-park-stone">Loading map…</p>
      </div>
    ),
  }
)
```

---

### Step 4: Create `ParkMap.tsx` (2 hours)

**Who**: Daphne
**File**: `src/components/ParkMap.tsx`
**Key decisions**:
- Use `APIProvider` from `@vis.gl/react-google-maps` (requires `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY`)
- `Map` component with `defaultCenter`/`defaultZoom`
- `AdvancedMarker` for each park with valid coordinates
- `InfoWindow` on click with park name + "View details" link
- Skip clustering initially (see Clustering section above)

**Wire into `ExplorerClient.tsx`**:
```tsx
// Replace the placeholder at line 157-163
{view === 'map' && (
  <>
    <a
      href="#main-content"
      className="text-xs text-park-forest hover:underline mb-2 inline-block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-park-forest"
    >
      Skip map, view as list
    </a>
    <ParkMap
      parks={accessibilityFilteredParks}
      onParkSelect={handleSelectPark}
    />
  </>
)}
```

---

### Step 5: Verify env vars + typecheck (15 min)

**Who**: Daphne
**What**:
- Ensure `.env.schema` has `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY` and `NEXT_PUBLIC_GOOGLE_MAP_ID`
- Run `npm run typecheck`
- Run `npm run lint`
- Test all three views in browser

---

## Summary

| Step | Component | Est. Time | Blocker |
|------|-----------|-----------|---------|
| 1 | Install `@vis.gl/react-google-maps` | 5 min | — |
| 2 | `ParkCardMinimal.tsx` | 45 min | Step 1 |
| 3 | Lazy-load wiring in `ExplorerClient.tsx` | 15 min | Step 2 |
| 4 | `ParkMap.tsx` | 2 hours | Step 3 |
| 5 | Typecheck + lint + manual test | 15 min | Step 4 |
| **Total** | | **~3.5 hours** | |

**Assignee**: Daphne (all steps)

**Definition of Done**:
- [ ] `ParkCardMinimal` renders in minimal view with proper layout + accessibility
- [ ] `ParkMap` renders in map view with pins for loaded parks
- [ ] InfoWindow opens on pin click, links to park detail
- [ ] "Skip map" link works (keyboard accessible)
- [ ] `npm run typecheck` passes
- [ ] `npm run lint` passes
- [ ] Manual test: all three views cycle correctly via `ViewToggle`
- [ ] Placeholder "coming soon" text removed from `ExplorerClient.tsx`

---

## Open Questions

1. **Google Map ID**: Does the user have a `NEXT_PUBLIC_GOOGLE_MAP_ID` set up in Google Cloud Console? If not, `Map` component can work without `mapId` but styled maps require it. *Recommendation*: proceed without `mapId` initially, add later if custom styling is needed.

2. **Marker clustering**: Deferred. Revisit if user testing shows crowding at zoom levels 3-5.

3. **Parks without coordinates**: ~470 NPS parks, some may not have `latitude`/`longitude`. Filter these out silently in `ParkMap` (they won't render a pin, which is acceptable).
